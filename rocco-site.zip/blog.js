async function loadPosts() {
  const postsContainer = document.getElementById('blog-list');
  const postFiles = [
    'blog/2025-08-10-first-post.md',
    'blog/another-post.md'
  ];

  for (let file of postFiles) {
    const response = await fetch(file);
    const text = await response.text();
    const title = text.split('\n')[0].replace('# ', '');
    const preview = text.split('\n').slice(1, 4).join(' ');
    const postHTML = `
      <div class="post">
        <a href="${file.replace('.md', '.html')}">${title}</a>
        <p>${preview}...</p>
      </div>
    `;
    postsContainer.innerHTML += postHTML;
  }
}

loadPosts();