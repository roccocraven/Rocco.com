# My First Post
Welcome to my blog! This is the first post.
I'll be writing about games, ideas, and random thoughts.
Stay tuned!