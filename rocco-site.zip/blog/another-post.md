# Another Post
This is another example blog entry.
You can add as many as you want inside the blog folder.
Each one will appear on the homepage.